/* ===========================================================
   OneStyleMariana — lógica de la tienda
   =========================================================== */

/* ------------------------- Datos ------------------------- */
const PRODUCTS = [
  { id:'corset-marfil',  name:'Corset Encaje Marfil',     desc:'Encaje francés, varillaje arquitectónico', price:120000, cat:'corsets',     sizes:['XS','S','M'],        img:null,                     color:'#EFE7D5', colorKey:'marfil', colorName:'Marfil' },
  { id:'corset-canela',  name:'Corset Canela de Lujo',    desc:'Detalles de encaje premium',               price:145000, cat:'corsets',     sizes:['XS','S'],            img:'img/corset-canela.jpg',  color:'#8B5A34', colorKey:'canela', colorName:'Canela' },
  { id:'body-nocturno',  name:'Body Malla Nocturno',      desc:'Manga larga, estilo minimalista',          price:128000, cat:'blusas',      sizes:['S','M','L'],         img:'img/body-nocturno.jpg',  color:'#201D18', colorKey:'negro',  colorName:'Medianoche' },
  { id:'corset-noir',    name:'Corset Encaje Noir',       desc:'Diseño floral contrastante',               price:160000, cat:'corsets',     sizes:['XS','S','M','L'],    img:'img/corset-noir.jpg',    color:'#17140F', colorKey:'negro',  colorName:'Noir' },
  { id:'top-escote',     name:'Top Escote Profundo',      desc:'Silueta fluida, cuello halter',            price:135000, cat:'blusas',      sizes:['S','M','L','XL'],    img:'img/top-escote.jpg',     color:'#17140F', colorKey:'negro',  colorName:'Negro' },
  { id:'pantalon-azul',  name:'Pantalón Azul Claro',      desc:'Detalle frontal ajustable',                price:120000, cat:'pantalones',  sizes:['S','M','L'],         img:null,                     color:'#4E6484', colorKey:'azul',   colorName:'Azul Claro' },
  { id:'top-carmesi',    name:'Top Esencial Carmesí',     desc:'Ajuste perfecto, manga corta',             price:115000, cat:'blusas',      sizes:['XS','S','M'],        img:'img/top-carmesi.jpg',    color:'#A31F2D', colorKey:'rojo',   colorName:'Carmesí' },
  { id:'corset-blanc',   name:'Corset Lencería Blanc',    desc:'Botones frontales decorativos',            price:180000, cat:'corsets',     sizes:['S','M'],             img:'img/corset-blanc.jpg',   color:'#F5F1E8', colorKey:'marfil', colorName:'Blanc' },
  { id:'jeans-wide',     name:'Jeans Wide Leg Premium',   desc:'Denim importado, corte relajado',          price:165000, cat:'pantalones',  sizes:['M','L','XL'],        img:'img/jeans-wide.jpg',     color:'#5C6D85', colorKey:'azul',   colorName:'Denim Claro' },
];

const money = n => '$' + n.toLocaleString('es-CO') + ' COP';
const byId  = id => PRODUCTS.find(p => p.id === id);

/* ------------------------- Plantillas ------------------------- */
function mediaHTML(p){
  return p.img
    ? `<img src="${p.img}" alt="${p.name}" loading="lazy">`
    : `<div class="card-placeholder"><i class="bi bi-bag"></i></div>`;
}

function cardHTML(p, col = 'col-6 col-lg-4'){
  return `
  <div class="${col}">
    <div class="product-card">
      <div class="card-media">
        <a href="#/producto/${p.id}">${mediaHTML(p)}</a>
        <button class="qv-btn" type="button" data-qv="${p.id}" aria-label="Vista rápida">
          <i class="bi bi-search"></i>
        </button>
      </div>
      <a href="#/producto/${p.id}">
        <h3>${p.name}</h3>
        <p class="desc">${p.desc}</p>
        <div class="d-flex justify-content-between align-items-center">
          <span class="price">${money(p.price)}</span>
          <span class="color-dot" style="background:${p.color}" title="${p.colorName}"></span>
        </div>
      </a>
    </div>
  </div>`;
}

/* ------------------------- Grids ------------------------- */
function renderHomeRecs(){
  const picks = ['corset-canela','top-carmesi','jeans-wide','body-nocturno'];
  document.getElementById('homeRecsGrid').innerHTML =
    picks.map(byId).filter(Boolean).map(p => cardHTML(p, 'col-6 col-lg-3')).join('');
}

function renderCuration(){
  document.getElementById('curationGrid').innerHTML =
    PRODUCTS.slice(0, 4).map(p => cardHTML(p, 'col-6 col-lg-3')).join('');
}

function renderSearchRecs(){
  const picks = ['top-escote','corset-noir'];
  document.getElementById('searchRecsGrid').innerHTML =
    picks.map(byId).filter(Boolean).map(p => cardHTML(p, 'col-12 col-md-6')).join('');
}

function renderCatalogBanner(){
  const picks = ['body-nocturno','corset-noir'];
  document.getElementById('catalogBannerStrip').innerHTML = picks.map(id => {
    const p = byId(id);
    if(!p) return '';
    return `
    <div class="banner-cell">
      <a href="#/producto/${p.id}">${mediaHTML(p)}</a>
      <div class="banner-caption">
        <h4>${p.name}</h4>
        <div class="price">${money(p.price)}</div>
      </div>
    </div>`;
  }).join('');
}

/* ------------------------- Filtros del catálogo ------------------------- */
let catalogCategory = 'todos';
let catalogSizes    = new Set();
let catalogColor    = '';

function renderCatalog(){
  const grid      = document.getElementById('catalogGrid');
  const emptyWrap = document.getElementById('catalogEmptyWrap');
  const countEl   = document.getElementById('catalogResultsCount');

  let list = catalogCategory === 'todos'
    ? PRODUCTS.slice()
    : PRODUCTS.filter(p => p.cat === catalogCategory);

  if(catalogSizes.size) list = list.filter(p => p.sizes.some(s => catalogSizes.has(s)));
  if(catalogColor)      list = list.filter(p => p.colorKey === catalogColor);

  if(!list.length){
    grid.innerHTML = '';
    grid.classList.add('d-none');
    emptyWrap.classList.remove('d-none');
    if(catalogCategory === 'vestidos'){
      document.getElementById('catalogEmptyTitle').textContent = 'Próximamente nuevas unidades';
      document.getElementById('catalogEmptyDesc').textContent  =
        'Estamos renovando nuestra selección de vestidos exclusivos. Muy pronto podrás descubrir piezas únicas.';
    }else{
      document.getElementById('catalogEmptyTitle').textContent = 'No encontramos prendas con estos filtros';
      document.getElementById('catalogEmptyDesc').textContent  =
        'Prueba con otra talla, color o tipo de prenda, o quita los filtros para ver toda la colección.';
    }
  }else{
    grid.classList.remove('d-none');
    emptyWrap.classList.add('d-none');
    grid.innerHTML = list.map(p => cardHTML(p)).join('');
  }

  countEl.textContent = `Mostrando ${list.length} de ${PRODUCTS.length} resultados`;
}

function initCatalogFilters(){
  document.getElementById('catalogCatFilter').addEventListener('click', e => {
    const btn = e.target.closest('.filter-opt');
    if(!btn) return;
    catalogCategory = btn.dataset.cat;
    document.querySelectorAll('#catalogCatFilter .filter-opt')
      .forEach(el => el.classList.toggle('active', el === btn));
    renderCatalog();
  });

  document.getElementById('catalogSizeFilter').addEventListener('click', e => {
    const chip = e.target.closest('.size-chip');
    if(!chip) return;
    const size = chip.dataset.size;
    if(catalogSizes.has(size)){ catalogSizes.delete(size); chip.classList.remove('active'); }
    else { catalogSizes.add(size); chip.classList.add('active'); }
    renderCatalog();
  });

  document.getElementById('catalogColorFilter').addEventListener('click', e => {
    const dot = e.target.closest('.color-pick');
    if(!dot) return;
    catalogColor = dot.dataset.color;
    document.querySelectorAll('#catalogColorFilter .color-pick')
      .forEach(el => el.classList.toggle('active', el === dot));
    renderCatalog();
  });

  document.getElementById('resetFiltersBtn').addEventListener('click', () => {
    catalogCategory = 'todos';
    catalogSizes.clear();
    catalogColor = '';
    document.querySelectorAll('#catalogCatFilter .filter-opt')
      .forEach(el => el.classList.toggle('active', el.dataset.cat === 'todos'));
    document.querySelectorAll('#catalogSizeFilter .size-chip').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('#catalogColorFilter .color-pick').forEach(el => el.classList.remove('active'));
    renderCatalog();
  });
}

/* ------------------------- Detalle de producto ------------------------- */
let currentProduct = null;

function loadProduct(id){
  const p = byId(id) || PRODUCTS[1];
  currentProduct = p;

  document.getElementById('pdpCrumb').innerHTML =
    `Lujo Importado / ${p.cat.charAt(0).toUpperCase() + p.cat.slice(1)} / <b>${p.name}</b>`;
  document.getElementById('pdpName').textContent  = p.name;
  document.getElementById('pdpPrice').textContent = money(p.price);
  document.getElementById('pdpDesc').textContent  =
    `${p.desc}. Confeccionado con materiales importados de la más alta calidad, una prenda diseñada para la mujer que valora la sofisticación en cada detalle.`;
  document.getElementById('pdpStock').textContent =
    `Quedan pocas unidades — tallas disponibles: ${p.sizes.join(', ')}`;

  document.getElementById('pdpMain').innerHTML = mediaHTML(p);
  document.getElementById('pdpThumbs').innerHTML = [0,1,2].map(i => `
    <div class="col-4 pdp-thumb">${mediaHTML(p).replace('<img', i === 0 ? '<img class="active"' : '<img')}</div>
  `).join('');

  document.getElementById('pdpSizes').innerHTML = ['XS','S','M','L','XL'].map(s => {
    const available = p.sizes.includes(s);
    return `<button class="size-chip ${available && s === p.sizes[0] ? 'active' : ''}"
             ${available ? '' : 'disabled style="opacity:.35"'} data-size="${s}">${s}</button>`;
  }).join('');

  document.getElementById('pdpColorLabel').textContent = `Color: ${p.colorName}`;
  document.getElementById('pdpColors').innerHTML =
    `<span class="color-pick active" style="background:${p.color}"></span>`;
}

function initPdp(){
  document.getElementById('pdpSizes').addEventListener('click', e => {
    const chip = e.target.closest('.size-chip');
    if(!chip || chip.disabled) return;
    document.querySelectorAll('#pdpSizes .size-chip').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
  });

  document.getElementById('pdpThumbs').addEventListener('click', e => {
    const img = e.target.closest('img');
    if(!img) return;
    document.querySelectorAll('#pdpThumbs img').forEach(i => i.classList.remove('active'));
    img.classList.add('active');
  });

  document.getElementById('addToCartBtn').addEventListener('click', () => {
    if(!currentProduct) return;
    const size = document.querySelector('#pdpSizes .size-chip.active')?.dataset.size || currentProduct.sizes[0];
    addToCart(currentProduct, `${currentProduct.colorName} / Talla ${size}`);
  });
}

/* ------------------------- Carrito ------------------------- */
let cart = [];
let cartDrawer = null;

function addToCart(p, variant){
  const existing = cart.find(i => i.id === p.id && i.variant === variant);
  if(existing) existing.qty++;
  else cart.push({ id:p.id, name:p.name, variant, price:p.price, qty:1, img:p.img });
  renderCart();
  cartDrawer.show();
}

function changeQty(idx, delta){
  cart[idx].qty = Math.max(1, cart[idx].qty + delta);
  renderCart();
}

function removeItem(idx){
  cart.splice(idx, 1);
  renderCart();
}

function cartTotals(){
  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const shipping = cart.length ? 45000 : 0;
  const tax      = Math.round(subtotal * 0.12 / 1000) * 1000;
  return { subtotal, shipping, tax, total: subtotal + shipping + tax };
}

function itemImg(item, cls = ''){
  return item.img
    ? `<img src="${item.img}" alt="${item.name}" class="${cls}">`
    : `<div class="card-placeholder ${cls}" style="aspect-ratio:auto;height:100%"><i class="bi bi-bag"></i></div>`;
}

function renderCart(){
  /* checkout */
  const wrap = document.getElementById('cartItemsWrap');
  if(!cart.length){
    wrap.innerHTML = `<div class="empty-cart">Tu selección está vacía.
      <a href="#/catalogo" class="link-osm text-decoration-underline">Explora la colección</a></div>`;
  }else{
    wrap.innerHTML = cart.map((item, idx) => `
      <div class="cart-item">
        ${itemImg(item)}
        <div>
          <h4>${item.name}</h4>
          <div class="meta">${item.variant}</div>
          <div class="qty">
            <button type="button" data-qty="-1" data-idx="${idx}">−</button>
            <span>${item.qty}</span>
            <button type="button" data-qty="1" data-idx="${idx}">+</button>
          </div>
        </div>
        <div class="text-end">
          <div class="price">${money(item.price * item.qty)}</div>
          <button class="remove" type="button" data-remove="${idx}">Eliminar</button>
        </div>
      </div>`).join('');
  }

  /* drawer */
  const drawer = document.getElementById('drawerItems');
  if(!cart.length){
    drawer.innerHTML = `<div class="empty-cart">Tu carrito está vacío.<br>
      <a href="#/catalogo" class="link-osm text-decoration-underline" data-bs-dismiss="offcanvas">Explorar colección</a></div>`;
  }else{
    drawer.innerHTML = cart.map((item, idx) => `
      <div class="drawer-item">
        ${itemImg(item)}
        <div>
          <h4>${item.name}</h4>
          <div class="meta">${item.variant}</div>
          <div class="d-flex justify-content-between align-items-center">
            <div class="qty">
              <button type="button" data-qty="-1" data-idx="${idx}">−</button>
              <span>${item.qty}</span>
              <button type="button" data-qty="1" data-idx="${idx}">+</button>
            </div>
            <div class="price">${money(item.price * item.qty)}</div>
          </div>
        </div>
      </div>`).join('');
  }

  const t = cartTotals();
  document.getElementById('sumSubtotal').textContent   = money(t.subtotal);
  document.getElementById('sumShip').textContent       = money(t.shipping);
  document.getElementById('sumTax').textContent        = money(t.tax);
  document.getElementById('sumTotal').textContent      = money(t.total);
  document.getElementById('drawerSubtotal').textContent = money(t.subtotal);
  document.getElementById('cartCount').textContent     = cart.reduce((s, i) => s + i.qty, 0);
}

function initCart(){
  cartDrawer = new bootstrap.Offcanvas('#cartDrawer');
  document.getElementById('cartBtn').addEventListener('click', () => cartDrawer.show());

  document.body.addEventListener('click', e => {
    const qtyBtn = e.target.closest('[data-qty]');
    if(qtyBtn){ changeQty(+qtyBtn.dataset.idx, +qtyBtn.dataset.qty); return; }
    const rmBtn = e.target.closest('[data-remove]');
    if(rmBtn){ removeItem(+rmBtn.dataset.remove); }
  });

  document.getElementById('drawerCheckoutBtn').addEventListener('click', () => cartDrawer.hide());
  document.getElementById('completeOrderBtn').addEventListener('click', completeOrder);
}

function completeOrder(){
  const err = document.getElementById('checkoutError');
  err.classList.add('d-none');

  if(!cart.length){
    err.textContent = 'Tu selección está vacía. Añade una prenda antes de completar el pedido.';
    err.classList.remove('d-none');
    return;
  }

  const fields = ['shipName','shipEmail','shipAddress','shipPhone','shipCity'].map(id =>
    document.getElementById(id).value.trim());

  if(fields.some(v => !v)){
    err.textContent = 'Completa nombre, correo, dirección, teléfono y ciudad para continuar.';
    err.classList.remove('d-none');
    return;
  }

  const orderId = 'ORD-' + Math.floor(10000 + Math.random() * 89999);
  cart = [];
  renderCart();

  location.hash = '#/seguimiento';
  document.getElementById('trackOrderId').value = orderId;
  document.getElementById('trackContact').value = fields[1];
  document.getElementById('trackAddress').textContent = `${fields[2]}, ${fields[4]}`;
  runTracking();
}

/* ------------------------- Vista rápida ------------------------- */
let qvModal = null;
let qvProduct = null;

function openQuickView(id){
  const p = byId(id);
  if(!p) return;
  qvProduct = p;

  document.getElementById('qvImage').innerHTML   = mediaHTML(p);
  document.getElementById('qvName').textContent  = p.name;
  document.getElementById('qvPrice').textContent = money(p.price);
  document.getElementById('qvColorDot').style.background = p.color;
  document.getElementById('qvColorName').textContent = `Color: ${p.colorName}`;
  document.getElementById('qvDesc').textContent  = p.desc + '.';
  document.getElementById('qvFullLink').setAttribute('href', `#/producto/${p.id}`);

  document.getElementById('qvSizes').innerHTML = ['XS','S','M','L','XL'].map(s => {
    const available = p.sizes.includes(s);
    return `<button class="size-chip ${available && s === p.sizes[0] ? 'active' : ''}"
             ${available ? '' : 'disabled style="opacity:.35"'} data-size="${s}">${s}</button>`;
  }).join('');

  qvModal.show();
}

function initQuickView(){
  qvModal = new bootstrap.Modal('#quickViewModal');

  document.body.addEventListener('click', e => {
    const btn = e.target.closest('[data-qv]');
    if(btn){ e.preventDefault(); openQuickView(btn.dataset.qv); }
  });

  document.getElementById('qvSizes').addEventListener('click', e => {
    const chip = e.target.closest('.size-chip');
    if(!chip || chip.disabled) return;
    document.querySelectorAll('#qvSizes .size-chip').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
  });

  document.getElementById('qvAddBtn').addEventListener('click', () => {
    if(!qvProduct) return;
    const size = document.querySelector('#qvSizes .size-chip.active')?.dataset.size || qvProduct.sizes[0];
    qvModal.hide();
    addToCart(qvProduct, `${qvProduct.colorName} / Talla ${size}`);
  });

  document.getElementById('qvFullLink').addEventListener('click', () => qvModal.hide());
}

/* ------------------------- Búsqueda ------------------------- */
const normalize = s => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

function runSearch(){
  const term = document.getElementById('searchInput').value.trim();
  const resultsWrap = document.getElementById('searchResultsWrap');
  const emptyWrap   = document.getElementById('searchEmptyWrap');

  if(!term){ clearSearch(); return; }

  const q = normalize(term);
  const results = PRODUCTS.filter(p =>
    normalize(p.name).includes(q) ||
    normalize(p.desc).includes(q) ||
    normalize(p.cat).includes(q)  ||
    normalize(p.colorName).includes(q));

  if(results.length){
    resultsWrap.classList.remove('d-none');
    emptyWrap.classList.add('d-none');
    document.getElementById('searchHeading').textContent = `Resultados para: "${term}"`;
    document.getElementById('searchCount').textContent =
      `${results.length} ${results.length === 1 ? 'resultado encontrado' : 'resultados encontrados'}`;
    document.getElementById('searchGrid').innerHTML = results.map(p => cardHTML(p)).join('');
  }else{
    resultsWrap.classList.add('d-none');
    emptyWrap.classList.remove('d-none');
    document.getElementById('noResultsHeading').textContent = `No encontramos resultados para "${term}"`;
  }
}

function clearSearch(){
  document.getElementById('searchInput').value = '';
  document.getElementById('searchResultsWrap').classList.add('d-none');
  document.getElementById('searchEmptyWrap').classList.remove('d-none');
  document.getElementById('noResultsHeading').textContent = 'No encontramos resultados';
}

function initSearch(){
  document.getElementById('searchBtn').addEventListener('click', runSearch);
  document.getElementById('searchInput').addEventListener('keydown', e => {
    if(e.key === 'Enter'){ e.preventDefault(); runSearch(); }
  });
  document.getElementById('clearSearchBtn').addEventListener('click', clearSearch);
}

/* ------------------------- Seguimiento ------------------------- */
function runTracking(){
  const id = document.getElementById('trackOrderId').value.trim();
  if(!id){ document.getElementById('trackOrderId').focus(); return; }
  document.getElementById('trackResultId').textContent = 'Pedido ' + id.toUpperCase();
  document.getElementById('trackResult').classList.remove('d-none');
}

function initTracking(){
  document.getElementById('trackBtn').addEventListener('click', runTracking);
}

/* ------------------------- Cuenta ------------------------- */
let currentUser = null;

function showError(id, msg){
  const el = document.getElementById(id);
  el.textContent = msg;
  el.classList.remove('d-none');
}

function resetAccountView(){
  document.getElementById('accountForms').classList.remove('d-none');
  document.getElementById('authSuccess').classList.add('d-none');
  document.getElementById('loginError').classList.add('d-none');
  document.getElementById('registerError').classList.add('d-none');
}

function finishAuth(title, sub){
  document.getElementById('accountForms').classList.add('d-none');
  document.getElementById('authSuccessTitle').textContent = title;
  document.getElementById('authSuccessSub').textContent   = sub;
  document.getElementById('authSuccess').classList.remove('d-none');
  updateAccountUI();
}

function updateAccountUI(){
  const label = document.getElementById('accountLabel');
  const icon  = document.getElementById('accountIcon');
  if(currentUser){
    label.textContent = currentUser.name.split(' ')[0];
    icon.className = 'bi bi-person-fill';
    document.getElementById('accountMenuName').textContent = currentUser.name;
  }else{
    label.textContent = 'Iniciar Sesión';
    icon.className = 'bi bi-person';
  }
}

function initAccount(){
  const menu = new bootstrap.Dropdown(document.getElementById('accountBtn'));

  document.getElementById('accountBtn').addEventListener('click', e => {
    if(currentUser){ menu.toggle(); }
    else { e.preventDefault(); location.hash = '#/cuenta'; }
  });

  document.getElementById('loginBtn').addEventListener('click', () => {
    document.getElementById('loginError').classList.add('d-none');
    const user = document.getElementById('loginUser').value.trim();
    const pass = document.getElementById('loginPassword').value;
    if(!user || !pass){ showError('loginError', 'Ingresa tu usuario y contraseña.'); return; }
    currentUser = { name:user, email:user };
    finishAuth('¡Bienvenida de nuevo!', `Iniciaste sesión como ${user}.`);
  });

  document.getElementById('registerBtn').addEventListener('click', () => {
    document.getElementById('registerError').classList.add('d-none');
    const name  = document.getElementById('regName').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const p1    = document.getElementById('regPassword').value;
    const p2    = document.getElementById('regPassword2').value;

    if(!name || !email || !p1 || !p2){ showError('registerError', 'Completa todos los campos.'); return; }
    if(!email.includes('@'))          { showError('registerError', 'Ingresa un correo electrónico válido.'); return; }
    if(p1.length < 6)                 { showError('registerError', 'La contraseña debe tener al menos 6 caracteres.'); return; }
    if(p1 !== p2)                     { showError('registerError', 'Las contraseñas no coinciden.'); return; }

    currentUser = { name, email };
    finishAuth('¡Cuenta creada!', `Bienvenida a OneStyleMariana, ${name.split(' ')[0]}.`);
  });

  document.getElementById('logoutBtn').addEventListener('click', () => {
    currentUser = null;
    updateAccountUI();
  });

  document.getElementById('forgotLink').addEventListener('click', e => e.preventDefault());
}

/* ------------------------- Router ------------------------- */
const ROUTES = ['catalogo','checkout','buscar','seguimiento','cuenta'];

function currentRoute(){
  const h = location.hash.replace(/^#\/?/, '');
  if(!h) return { name:'home' };
  const parts = h.split('/');
  if(parts[0] === 'producto') return { name:'pdp', id:parts[1] };
  if(ROUTES.includes(parts[0])) return { name:parts[0] };
  return { name:'404' };
}

function render(){
  const r = currentRoute();
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  const el = document.getElementById('view-' + r.name) || document.getElementById('view-404');
  el.classList.add('active');

  document.querySelectorAll('.nav-route').forEach(a =>
    a.classList.toggle('active', a.dataset.route === r.name));

  if(r.name === 'pdp')    loadProduct(r.id);
  if(r.name === 'cuenta') resetAccountView();

  /* cerrar menú móvil */
  const nav = document.getElementById('mainNav');
  if(nav.classList.contains('show')) bootstrap.Collapse.getOrCreateInstance(nav).hide();

  window.scrollTo({ top:0, behavior:'instant' });
}

/* ------------------------- Arranque ------------------------- */
window.addEventListener('hashchange', render);

document.addEventListener('DOMContentLoaded', () => {
  renderHomeRecs();
  renderCatalog();
  renderCatalogBanner();
  renderCuration();
  renderSearchRecs();
  renderCart();

  initCatalogFilters();
  initPdp();
  initCart();
  initQuickView();
  initSearch();
  initTracking();
  initAccount();

  clearSearch();
  updateAccountUI();
  render();
});
